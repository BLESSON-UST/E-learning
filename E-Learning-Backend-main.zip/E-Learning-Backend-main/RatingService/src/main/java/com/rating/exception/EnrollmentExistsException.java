package com.rating.exception;

public class EnrollmentExistsException extends RuntimeException {

    public EnrollmentExistsException(String message) {
        super(message);
    }

}
