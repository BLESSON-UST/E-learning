package com.enrollment.EnrollmentService.exception;

public class EnrollmentExistsException extends RuntimeException {

    public EnrollmentExistsException(String message) {
        super(message);
    }

}
