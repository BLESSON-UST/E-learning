package com.enrollment.EnrollmentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrollmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
